<template>
    <div class="footer-wrapper">
        <h1>footer</h1>
    </div>
</template>

<script setup>
</script>

<script>

</script>

<style scoped>

</style>