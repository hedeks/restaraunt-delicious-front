<script setup>
</script>

<template>
  <div id="cart-wrapper">
    <h1>КОРЗИНА СТРАНИЦА</h1>
  </div>
</template>

<style scoped>

</style>