<script setup>
</script>

<template>
  <div class="contacts-wrapper">
    <h1>КОНТАКТЫ СТРАНИЦА БАМ</h1>
  </div>
</template>

<style scoped>
.contacts-wrapper {
  height: calc(100vh - 167px);
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
}
</style>