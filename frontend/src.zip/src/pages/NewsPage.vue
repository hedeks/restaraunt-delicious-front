<script setup>
import NewsSlider from '../components/NewsSlider.vue';
</script>

<template>
  <div id="news-wrapper">
      <NewsSlider/>
  </div>
</template>

<style scoped>

</style>