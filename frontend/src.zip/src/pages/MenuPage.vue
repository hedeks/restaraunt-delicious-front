<script setup>
</script>

<template>
  <div id="menu-wrapper">
    <h1>МЕНЮ СТРАНИЦа БАМ</h1>
  </div>
</template>

<style scoped>

</style>